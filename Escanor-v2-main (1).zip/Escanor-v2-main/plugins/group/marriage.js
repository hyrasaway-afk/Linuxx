const handler = async (m, { conn }) => {
const participants = await conn.groupMetadata(m.chat).then(metadata => metadata.participants);
const jids = participants.map(p => p.id);

if (jids.length < 2) {
    return conn.sendMessage(m.chat, { text: "المجموعة صغيرة جداً" });
}

let index1 = Math.floor(Math.random() * jids.length);
let index2;

do {
    index2 = Math.floor(Math.random() * jids.length);
} while (index2 === index1 && jids.length > 1);

const user1 = jids[index1];
const user2 = jids[index2];

const content = {
    user1: user1,
    num1: (Math.floor(Math.random() * 100) + 1) + '%',
    user2: user2,
    num2: (Math.floor(Math.random() * 100) + 1) + '%'
};

return conn.sendMessage(m.chat, { 
    text: `*🥳 مبروك الزواج تمني لكم كل خير 🥳*

*🤵🏻 العريس:* @${content.user1.split('@')[0]} 
*🌹 نسبة حبه للعروسه:* ${content.num1}

*👰🏻‍♀️ العروسه:* @${content.user2.split('@')[0]} 
*🌹 نسبة حبها للعريس:* ${content.num2}`, 
    mentions: [content.user1, content.user2] 
}, { quoted: m });
};

handler.usage =  ["زواج"];
handler.category = "group";
handler.command = ["زواج"];

export default handler;